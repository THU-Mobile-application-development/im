package com.ceocho.kakaotalk.Notifications;

public class MyResponse {

    public int success;
}
